#ifndef MARCHE_H
#define MARCHE_H

#include <QGraphicsRectItem>

class marche : QGraphicsRectItem
{
public:
    marche();
    ~marche();
};

#endif // MARCHE_H
