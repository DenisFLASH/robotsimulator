#ifndef CENTRETERRAIN_H
#define CENTRETERRAIN_H

#include <QGraphicsRectItem>



class centreTerrain :public QGraphicsRectItem
{
public:
    centreTerrain();
    ~centreTerrain();
};

#endif // CENTRETERRAIN_H
