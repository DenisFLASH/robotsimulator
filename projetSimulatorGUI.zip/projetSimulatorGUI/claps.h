#ifndef CLAPS_H
#define CLAPS_H

#include <QGraphicsRectItem>

class claps :public QGraphicsRectItem
{
public:
    claps();
    ~claps();
};

#endif // CLAPS_H
