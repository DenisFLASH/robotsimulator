#include "zonedepart.h"

#include <QtGui>

zoneDepart::zoneDepart()
{
    setRect(0,200,100,10);
    setBrush(QBrush(Qt::yellow));
}

zoneDepart::~zoneDepart()
{

}

