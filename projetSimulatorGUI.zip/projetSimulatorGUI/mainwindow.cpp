#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QGraphicsView>
#include "scene.h"
#include "viewgame.h"
#include <QHBoxLayout>
#include <QtGui>

MainWindow::MainWindow(QWidget *parent) :QWidget(parent)
{

       //viewGame *view = new viewGame("Top left view");
       //setWindowTitle(tr("SimulatorGame"));

}

MainWindow::~MainWindow()
{
}
