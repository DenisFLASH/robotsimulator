#ifndef ZONEDEPART_H
#define ZONEDEPART_H

#include <QGraphicsRectItem>

class zoneDepart: public QGraphicsRectItem
{
public:
    zoneDepart();
    ~zoneDepart();
};

#endif // ZONEDEPART_H
