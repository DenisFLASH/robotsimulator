#ifndef ESCALIERS_H
#define ESCALIERS_H

#include <QGraphicsRectItem>

class Escaliers : public QGraphicsRectItem
{
public:
    Escaliers();
    ~Escaliers();
private:
};

#endif // ESCALIERS_H
