#include "Cerveau.h"


int main()
{
    Cerveau* brain = new Cerveau();
}

