#include <QtGui>
#include <QApplication>
#include <QGraphicsView>
#include "Scene.h"
#include "PlayingArea.h"
#include "Robot.h"
#include "Parameters.h"
#include "StrategieGlobale.h"
#include "SimulatorEngine.h"
using namespace Parameters;


int main(int argc, char** argv)
{
    Robot* ryad = new Robot("Ryad", TEAM_A_MAIN_ROBOT_INIT_X, TEAM_A_MAIN_ROBOT_INIT_Y,
                            TEAM_A_MAIN_ROBOT_LENGTH, TEAM_A_MAIN_ROBOT_WIDTH, 0.75 * PI);
    StrategieGlobale* brain = new StrategieGlobale();
    ryad->bindServiceInitialisation(brain);
    ryad->bindServicePasAPas(brain);
    brain->bindServiceActionMoteur(ryad);
    //brain->bindServiceActionPince(ryad);
    //brain->bindServiceCapteur(ryad);

    PlayingArea* area = new PlayingArea();
    area->setTheOnlyRobot(ryad);

    SimulatorEngine* engine = new SimulatorEngine();
    engine->bindPlayingArea(area);

    // idée: SupportGUI* gui = new SupportGUI();   gui->bindPlayingArea(area);



    // Towers  /////////////////////////////////////////////////
    QApplication app(argc, argv);
    //QWidget widget; widget.showMaximized();

    Scene scene(area);
    QGraphicsView view(&scene);
    //QTimer timer;
    //QObject::connect(&timer, SIGNAL(timeout()), &scene, SLOT(advance()));
    view.show();
    //timer.start(10);
    // /////////////////////////////////////////////////////////



    /*engine->run();*/

    QTimer timer;
    QObject::connect(&timer, SIGNAL(timeout()), scene, SLOT(advance()));
    //int FPS = 50;
    timer.start(1000 / 50);


    delete engine;
    delete area;
    delete brain;
    delete ryad;

    return app.exec();
}

